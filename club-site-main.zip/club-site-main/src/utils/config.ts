export const config = {
    site_name: 'Computer Club Website',
    title: 'Computer Club Website',
    description: 'Come join the computer club to learn how to code and get coding help!',
    locale: 'en',
};